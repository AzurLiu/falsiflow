# NHI-PEDOT H-A RFQ Dispatch Archive

This archive contains local files for manually sending the first-wave H-A RFQs.

- Status: `h_a_rfq_dispatch_archive_ready`
- Vendor rows: 4
- Included files: 22
- Missing files: 0
- Hash mismatches: 0

Use the files in `vendors/` to open each prepared `.eml` draft and verify the matching bundle.
After each real send, save the original sent-email export, web-form confirmation, PDF, or screenshot at the path listed in the dispatch manifest.

Boundary:
The RFQ dispatch archive is a convenience package for manual outreach only. It is not a send confirmation, vendor reply, measurement result, or material suitability claim.
