# ZRC-ND Phase A RFQ Dispatch Archive

This archive contains local files for manually sending first-wave ZRC-ND Phase A RFQs.

- Status: `zrc_phase_a_rfq_dispatch_archive_ready`
- Vendor rows: 4
- Included files: 24
- Missing files: 0
- Hash mismatches: 0

Use the files in `vendors/` to send or paste the RFQ text and attach/upload the matching bundle.
After each real send, save the original sent-email export, web-form confirmation, PDF, or screenshot at the path listed in the dispatch manifest.

Boundary:
The ZRC-ND Phase A RFQ dispatch archive is a convenience package for manual outreach only. It is not a send confirmation, vendor reply, measurement result, or material suitability claim.
